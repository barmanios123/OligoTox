# OligoTox Dataset Download Guide

## Quick Start

```bash
cd ~/oligotox
bash oligotox_dataset_download.sh          # Step 1: bulk download
python oligotox/scripts/geo_fetch.py       # Step 2: GEO transcriptomics
python oligotox/scripts/sider_parse.py     # Step 3: SIDER AE labels
python oligotox/scripts/chembl_oligo_parse.py  # Step 4: ChEMBL profiles
```

---

## Dataset Priority Order

### TIER 1 — Label your endpoint matrix right now

| File | Source URL | Endpoints unlocked | Format |
|---|---|---|---|
| `fda_three_aso_impurities.pdf` | https://www.fda.gov/media/168708/download | hepatocellular_injury, renal_tubular_injury | PDF → manual extract |
| `janas_2018_galnac_nonclinical_safety.pdf` | https://pmc.ncbi.nlm.nih.gov/articles/PMC6249674/ | complement_activation, cytokine_release, hepatocellular_injury | PDF → manual extract |
| `dieckmann_2018_hybridization_gapmer_tox.pdf` | https://pmc.ncbi.nlm.nih.gov/articles/PMC5725219/ | offtarget_gene_silencing, hepatocellular_injury | PDF → manual extract |
| `burel_2016_rnash1_gapmer_hepatotox.pdf` | https://pmc.ncbi.nlm.nih.gov/articles/PMC4797265/ | hepatocellular_injury, offtarget_gene_silencing | PDF → manual extract |
| `unitox_2418_drugs.csv` | https://zenodo.org/records/14042913/files/UniTox.csv | hepatocellular_injury calibration | CSV, direct |
| `sider4_meddra_all_se.tsv.gz` | http://sideeffects.embl.de/media/download/meddra_all_se.tsv.gz | thrombocytopenia, complement, renal (approved drugs) | TSV.gz, parsed by sider_parse.py |
| `sider4_drug_names.tsv` | http://sideeffects.embl.de/media/download/drug_names.tsv | drug name → STITCH ID mapping | TSV, direct |
| `sider4_meddra_freq.tsv.gz` | http://sideeffects.embl.de/media/download/meddra_freq.tsv.gz | AE frequency for oligo drugs | TSV.gz |
| `scaso/` (GitHub) | https://github.com/ericminikel/scaso | cns_delayed_neurotoxicity (cell-type knockdown) | R dataset + CSV |
| `nhp_deepbrain_aso/` (GitHub) | https://github.com/ericminikel/nhp_deepbrain_aso | cns_delayed_neurotoxicity (NHP) | R dataset |

### TIER 2 — Sequence/chemistry with partial endpoint coverage

| File | Source URL | Endpoints | Notes |
|---|---|---|---|
| `sirnamod_all_entries.csv` | http://crdd.osdd.net/servers/sirnamod/dd.php | offtarget_gene_silencing, innate_immune_activation | Click "Download data in CSV format" |
| `papargyri_2020_aso_design_rules.pdf` | https://pmc.ncbi.nlm.nih.gov/articles/PMC6965521/ | offtarget_gene_silencing | **768 gapmers + caspase labels** — gold standard D2 dataset |
| `toxsirna_2026_preprint.pdf` | https://www.biorxiv.org/content/10.64898/2026.02.12.705521v1 | innate_immune_activation, offtarget_gene_silencing | 882 modified siRNAs, tox score 0-1 |
| `toxsirna_2026_supplemental` | https://www.biorxiv.org/content/10.64898/2026.02.12.705521v1 | same | **Download supplementary Excel manually** |
| `alnylam_capella_galnac_platform_slides_2018.pdf` | https://capella.alnylam.com/wp-content/uploads/2018/05/ABS_Capella-Slides_FINAL05092018.pdf | complement_activation, renal_tubular_injury | Platform-level GalNAc safety data |
| `ClinASO/` (GitHub) | https://github.com/wusuw/ClinASO | exaggerated_pharmacology, offtarget_gene_silencing | Gapmer design + efficacy |
| `openASO/` (GitHub) | https://github.com/lackeylela/openASO | D1 features | ENCODE eCLIP-based targeting |
| `llm_aso_efficacy_benchmark_2026.pdf` | https://www.biorxiv.org/content/10.64898/2026.02.17.706455v1 | sequence features | Efficacy → invert as tox proxy |

### TIER 3 — Mechanistic/omics (v0.4 calibration)

| File | Source URL | Use |
|---|---|---|
| `holistic_sirna_tox_review_2023.pdf` | https://pmc.ncbi.nlm.nih.gov/articles/PMC10543595/ | Label definition logic for all 13 endpoints |
| `preclinical_safety_oligos_ncbi_bookshelf.html` | https://www.ncbi.nlm.nih.gov/books/NBK584239/ | ICH/FDA assay framework |
| `chembl_oligo_drug_profiles.csv` | ChEMBL API (auto-fetched by chembl_oligo_parse.py) | Approved oligo HELM + MoA |
| `chembl_approved_oligonucleotides.json` | https://www.ebi.ac.uk/chembl/api/data/molecule.json?molecule_type=Oligonucleotide | Raw API pull |
| `DILI_srijitseal/` (GitHub) | https://github.com/srijitseal/DILI | DILI feature engineering reference |
| GEO accessions (see geo_accessions_to_fetch.txt) | https://www.ncbi.nlm.nih.gov/gds | Transcriptomics for D2 omics scoring |
| `htp_hepatotoxicity_portal_landing.html` | https://kobic.re.kr/htp/ | DILI database + GNN predictions |

---

## Manual Downloads Required

These cannot be curl'd due to auth/JavaScript walls:

| What | Where | Why it matters |
|---|---|---|
| **Papargyri 2020 supplementary data** (768-gapmer CSV) | https://pmc.ncbi.nlm.nih.gov/articles/PMC6965521/ → Supplementary | Core D2 training set — caspase >300% labels |
| **TOXsiRNA supplementary Excel** (882 siRNA tox scores) | https://www.biorxiv.org/content/10.64898/2026.02.12.705521v1 → Supplementary | 882 rows of labeled modified siRNAs |
| **siRNAmod CSV export** | http://crdd.osdd.net/servers/sirnamod/dd.php | All chemically modified siRNA entries |
| **FDA LTKB DILIrank Excel** | https://www.fda.gov/science-research/liver-toxicity-knowledge-base-ltkb/ltkb-benchmark-dataset | 1036-drug 4-class hepatotox benchmark |
| **siRNAmod ML paper supplementary** | https://www.sciencedirect.com/science/article/pii/S0888754324000363 | Processed feature tables |
| **FDA NDA labels** for 6 oligos | https://www.accessdata.fda.gov/scripts/cder/daf/ → search: patisiran, inotersen, inclisiran, givosiran, nusinersen, vutrisiran | Ground-truth clinical AE labels |
| **NIH OligoTox Challenge data** (Phase 2, active) | Contact: ncatsoligotox@mail.nih.gov | Public datasets from winning submissions |

---

## Labeling Thresholds (13 endpoints)

See `oligotox_labeling_scheme.csv` for full definitions. Key thresholds:

| Endpoint | Label=1 threshold | Source |
|---|---|---|
| hepatocellular_injury | ALT ≥3× ULN OR histopath ≥Grade2 | Dieckmann 2018; FDA 3-ASO |
| offtarget_gene_silencing | Caspase ≥300% control OR ≥50 off-target DEGs | Papargyri 2020 |
| thrombocytopenia | Platelet <75% baseline | Inotersen NDA |
| complement_activation | C3a ≥2× OR SC5b-9 ≥2× baseline | Patisiran NDA; Janas 2018 |
| innate_immune_activation | IL-6 ≥5× OR IFN-a ≥3× baseline (PBMC) | TOXsiRNA 2026 |
| cns_delayed_neurotoxicity | CSF NfL ≥2× baseline ≥28d post-dose | scASO Minikel 2023 |

