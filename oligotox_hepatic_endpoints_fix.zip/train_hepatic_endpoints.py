#!/usr/bin/env python3
"""
train_hepatic_endpoints.py
──────────────────────────
Trains endpoint-specific binary classifiers for:
  - hepatic_vacuolation
  - kupffer_activation

Inputs (all from data/processed/):
  training_dataset_v2.csv  — merged + augmented dataset
  dataset_metadata_v2.json — updated metadata with endpoint list

Outputs (to models/):
  hepatic_vacuolation_rf.pkl
  kupffer_activation_rf.pkl
  hepatic_vacuolation_metrics.json
  kupffer_activation_metrics.json

Usage:
    python train_hepatic_endpoints.py \
        --dataset data/processed/training_dataset_v2.csv \
        --meta    data/processed/dataset_metadata_v2.json \
        --outdir  models/
"""

import argparse
import json
import pickle
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.metrics import (classification_report, roc_auc_score,
                              average_precision_score, confusion_matrix)
from sklearn.preprocessing import LabelEncoder

warnings.filterwarnings("ignore")


# ── Feature engineering ──────────────────────────────────────────────────────
TOXIC_MOTIFS = ["TCC", "TGC", "CTGT"]           # Burdick 2014 + Levin communication
CpG_IMPORT   = ["CG"]
LNA_HIGH_AFF = ["LNA", "cEt"]
LNP_CARRIERS = ["LNP"]

def count_motif(seq: str, motif: str) -> int:
    return seq.upper().count(motif.upper())

def gc_content(seq: str) -> float:
    seq = seq.upper()
    if not seq:
        return 0.0
    return (seq.count("G") + seq.count("C")) / len(seq)

def has_cpg(seq: str) -> int:
    return int("CG" in seq.upper())

def is_high_affinity(chem: str) -> int:
    return int(any(x in chem for x in LNA_HIGH_AFF))

def is_lnp(chem: str) -> int:
    return int(any(x in chem for x in LNP_CARRIERS))

def is_galnac(chem: str) -> int:
    return int("GalNAc" in chem or "galnac" in chem.lower())

def modality_encode(mod: str) -> dict:
    mods = ["ASO_gapmer", "ASO_MOE", "ASO_PS", "ASO_lncRNA", "siRNA"]
    return {f"mod_{m.lower()}": int(mod == m) for m in mods}

def dinucleotide_features(seq: str) -> dict:
    """Count all dinucleotide occurrences (Hagedorn 2013 approach)."""
    bases = "ACGT"
    seq = seq.upper()
    feats = {}
    for b1 in bases:
        for b2 in bases:
            di = b1 + b2
            feats[f"di_{di}"] = seq.count(di)
    return feats

def trinucleotide_toxic_features(seq: str) -> dict:
    """Targeted toxic motif counts (Burdick 2014)."""
    seq = seq.upper()
    return {
        "tri_TCC": seq.count("TCC"),
        "tri_TGC": seq.count("TGC"),
        "tri_CTGT": seq.count("CTGT"),
        "has_toxic_motif": int(any(seq.count(m) > 0 for m in ["TCC", "TGC"])),
    }

def featurize(df: pd.DataFrame) -> pd.DataFrame:
    """Build the full feature matrix from raw sequence+metadata columns."""
    records = []
    for _, row in df.iterrows():
        seq  = str(row.get("sequence", "")).upper().strip()
        chem = str(row.get("chemistry", ""))
        mod  = str(row.get("modality", ""))

        feat = {
            "seq_len":         len(seq),
            "gc_content":      gc_content(seq),
            "has_cpg":         has_cpg(seq),
            "is_high_affinity": is_high_affinity(chem),
            "is_lnp":          is_lnp(chem),
            "is_galnac":       is_galnac(chem),
            "has_ps":          int("PS" in chem),
            "has_moe":         int("MOE" in chem),
        }
        feat.update(dinucleotide_features(seq))
        feat.update(trinucleotide_toxic_features(seq))
        feat.update(modality_encode(mod))
        records.append(feat)

    return pd.DataFrame(records)


# ── Training / evaluation ────────────────────────────────────────────────────
def train_endpoint(X: pd.DataFrame, y: pd.Series,
                   endpoint: str, outdir: Path) -> dict:
    """
    Trains RandomForest with StratifiedKFold CV.
    Falls back to Logistic Regression if class imbalance is extreme.
    Saves model artifact and returns metrics dict.
    """
    n_pos = int(y.sum())
    n_neg = int((y == 0).sum())
    print(f"  [{endpoint}] n_pos={n_pos}  n_neg={n_neg}  total={len(y)}")

    if n_pos < 3:
        print(f"  WARN: too few positives for {endpoint} — skipping model training")
        return {"endpoint": endpoint, "status": "skipped_insufficient_positives",
                "n_positive": n_pos, "n_negative": n_neg}

    # Class weight to handle imbalance
    cw = "balanced" if n_pos / len(y) < 0.3 else None

    clf = RandomForestClassifier(
        n_estimators=500,
        max_features="sqrt",
        class_weight=cw,
        random_state=42,
        n_jobs=-1,
    )

    cv = StratifiedKFold(n_splits=min(5, n_pos), shuffle=True, random_state=42)
    cv_results = cross_validate(
        clf, X, y, cv=cv,
        scoring=["roc_auc", "average_precision", "f1"],
        return_train_score=False,
    )

    # Train on full dataset for final model
    clf.fit(X, y)

    # Save model
    model_path = outdir / f"{endpoint}_rf.pkl"
    with open(model_path, "wb") as f:
        pickle.dump({"model": clf, "feature_names": list(X.columns),
                     "endpoint": endpoint}, f)

    # Feature importance top 10
    importances = pd.Series(clf.feature_importances_, index=X.columns)
    top_features = importances.nlargest(10).to_dict()

    metrics = {
        "endpoint": endpoint,
        "status": "trained",
        "n_positive": n_pos,
        "n_negative": n_neg,
        "cv_roc_auc_mean": float(np.mean(cv_results["test_roc_auc"])),
        "cv_roc_auc_std":  float(np.std(cv_results["test_roc_auc"])),
        "cv_avg_precision_mean": float(np.mean(cv_results["test_average_precision"])),
        "cv_f1_mean": float(np.mean(cv_results["test_f1"])),
        "top_features": {k: float(v) for k, v in top_features.items()},
        "model_path": str(model_path),
    }

    print(f"  ROC-AUC={metrics['cv_roc_auc_mean']:.3f} ± {metrics['cv_roc_auc_std']:.3f}  "
          f"AP={metrics['cv_avg_precision_mean']:.3f}  F1={metrics['cv_f1_mean']:.3f}")

    return metrics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="data/processed/training_dataset_v2.csv")
    parser.add_argument("--meta",    default="data/processed/dataset_metadata_v2.json")
    parser.add_argument("--outdir",  default="models/")
    args = parser.parse_args()

    dataset_path = Path(args.dataset)
    meta_path    = Path(args.meta)
    outdir       = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    print(f"Loading dataset from {dataset_path}")
    df = pd.read_csv(dataset_path)
    print(f"  {len(df)} rows, columns: {list(df.columns)}")

    ENDPOINTS = ["hepatic_vacuolation", "kupffer_activation"]
    for ep in ENDPOINTS:
        if f"label_{ep}" not in df.columns:
            raise ValueError(f"Missing column label_{ep} — run augment_hepatic_labels.py first")

    print("\nFeaturizing sequences...")
    X = featurize(df)
    print(f"  Feature matrix: {X.shape}")

    all_metrics = []
    for ep in ENDPOINTS:
        print(f"\nTraining: {ep}")
        y = df[f"label_{ep}"].fillna(0).astype(int)
        metrics = train_endpoint(X, y, ep, outdir)
        all_metrics.append(metrics)

        metrics_path = outdir / f"{ep}_metrics.json"
        with open(metrics_path, "w") as f:
            json.dump(metrics, f, indent=2)
        print(f"  Metrics → {metrics_path}")

    summary_path = outdir / "hepatic_endpoints_training_summary.json"
    with open(summary_path, "w") as f:
        json.dump(all_metrics, f, indent=2)
    print(f"\nSummary → {summary_path}")
    print("\nDone.")


if __name__ == "__main__":
    main()
