# Hepatic Endpoint Labeled Examples — OligoTox

Generated: June 29, 2026
Purpose: Provide labeled training data and integration code to fix the
`hepatic_vacuolation` and `kupffer_activation` endpoint classifiers in OligoTox.

---

## Files in This Package

| File | Purpose |
|------|---------|
| `hepatic_endpoints_labeled.csv` | 39 gold-labeled sequences with binary labels for both endpoints |
| `hepatic_endpoints_evidence_registry.json` | Mechanism definitions, predictive rules, biomarkers, primary sources |
| `augment_hepatic_labels.py` | Merges gold labels + rule-based augmentation into training_dataset_v2.csv |
| `train_hepatic_endpoints.py` | Trains RF classifiers for both endpoints with CV evaluation |
| `validate_hepatic_labels.ipynb` | Label QC notebook: class balance, motif concordance, feature importance |

---

## Evidence Tiers

- **T1** (n=25): Primary in vivo mouse studies with confirmed H&E histopathology
  - Burdick et al. 2014 (Nucleic Acids Res) — LNA 3-8-3 gapmer TCC/TGC motifs
  - Burel et al. 2015 (Nucleic Acids Res) — LNA 3-10-3 off-target RNase H1 mechanism
- **T2** (n=11): Review articles, class-effect literature, mechanistic reviews
  - SOT 2010 Oligonucleotide Therapeutics toxicological considerations
  - Sage Journals 2015 ASO Therapies review (Henry laboratory)
  - Frontiers Pharmacology 2022 ASO liver review
- **T3** (n=3): Mechanism-inference from MASLD/DEG context (your HNF1AOS1 research)

---

## Label Definitions

### hepatic_vacuolation
Intracytoplasmic vacuolation in hepatocytes or Kupffer cells on H&E.
- **Drug-accumulation vacuolation** (MOE/PS in Kupffer cells) = NOT adverse per FDA/OSWG framing
- **Hepatocellular vacuolation concurrent with ALT elevation** = ADVERSE
- **Macrovesicular vacuolation in MASLD background** = ADVERSE (D1 on-target exaggeration)

### kupffer_activation
KC activation defined by phagocytic uptake + cytokine release (TNF-α, IL-6, IL-1β) +
mononuclear infiltration on H&E.
- **Mild vacuolization only** = NOT adverse
- **KC activation with hepatocellular injury or elevated ALT** = ADVERSE

---

## Integration Steps

### Step 1 — Copy labeled CSV to processed data directory
```bash
cp hepatic_endpoints_labeled.csv data/processed/
cp hepatic_endpoints_evidence_registry.json data/processed/
```

### Step 2 — Augment training dataset
```bash
python augment_hepatic_labels.py \
    --labeled  data/processed/hepatic_endpoints_labeled.csv \
    --training data/processed/training_dataset.csv \
    --meta     data/processed/dataset_metadata.json \
    --out      data/processed/training_dataset_v2.csv
```

### Step 3 — Train endpoint models
```bash
python train_hepatic_endpoints.py \
    --dataset data/processed/training_dataset_v2.csv \
    --meta    data/processed/dataset_metadata_v2.json \
    --outdir  models/
```
Outputs: `models/hepatic_vacuolation_rf.pkl`, `models/kupffer_activation_rf.pkl`

### Step 4 — Validate labels and model quality
Open `validate_hepatic_labels.ipynb` in JupyterLab and run all cells.
Check:
- Class balance (target: ≥ 5 positives per endpoint)
- Motif concordance (TCC/TGC in LNA/cEt should match vacuolation=1)
- CV ROC-AUC ≥ 0.70 before trusting predictions

### Step 5 — Register models in OligoTox app
Add to your model registry loader in `src/oligotox/`:
```python
ENDPOINT_MODELS = {
    ...
    "hepatic_vacuolation": "models/hepatic_vacuolation_rf.pkl",
    "kupffer_activation":  "models/kupffer_activation_rf.pkl",
}
```
Ensure `featurize()` from `train_hepatic_endpoints.py` is called from the
same feature-engineering module used during inference.

---

## Key Predictive Rules (for rule-based fallback in absence of model)

### hepatic_vacuolation
| Rule | Chemistry | Basis |
|------|-----------|-------|
| TCC or TGC trinucleotide in gap | LNA/cEt 3-8-3 or 3-10-3 gapmer | Burdick 2014 T1 (PPV ~90%) |
| LNP carrier | Any modality | Lipid vacuolation via KC phagocytosis |
| Chronic high-dose PS + high-affinity modification | MOE/LNA/cEt gapmer | SOT 2010, Henry 2008 |
| MASLD disease background + lipogenic DEG signature | Any | D1 on-target exaggeration |

### kupffer_activation
| Rule | Chemistry | Basis |
|------|-----------|-------|
| Unmethylated CpG motif | Any PS backbone | TLR9-KC axis |
| LNP carrier (ionizable or cationic) | siRNA-LNP | NLRP3/TLR4 inflammasome |
| First-gen fully PS ASO | PS-only backbone | Polyanion complement activation |
| PS backbone length > 20mer systemic | Any gapmer | Class effect threshold |

---

## Literature Sources

1. Burdick et al. (2014) *Nucleic Acids Res* 42(8):4882–4891 — PMID 24550163
   TCC/TGC motifs predict LNA 3-8-3 gapmer hepatotoxicity; RF model sensitivity 90%

2. Burel et al. (2015) *Nucleic Acids Res* 44(5):2093–2109 — PMID 26553810
   RNase H1-dependent off-target cleavage of very long pre-mRNAs (>125kb) drives LNA hepatotoxicity

3. Henry et al. (2002) *PubMed* 11991849
   KC-derived TNF-α/prostanoids as primary hepatotoxicity drivers; ASO targeting of KCs

4. SOT 2010 Toxicological Considerations for Oligonucleotide Therapeutics
   Class effects: Kupffer cell vacuolization, mononuclear phagocyte drug accumulation, TLR9/CpG

5. Sage Journals (2015) ASO Therapies review — DOI 10.1177/0192623314551840
   LNA immunomodulation via KC activation; hepatocellular degeneration + inflammatory infiltrate

6. Frontiers Pharmacology (2022) ASO liver review — DOI 10.3389/fphar.2022.1061842
   GalNAc-siRNA KC activation; Tnf-alpha ASO via galactosylated chitosan to KCs
