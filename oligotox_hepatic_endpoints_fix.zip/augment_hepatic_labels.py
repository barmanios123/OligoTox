#!/usr/bin/env python3
"""
augment_hepatic_labels.py
─────────────────────────
Reads hepatic_endpoints_labeled.csv and data/processed/training_dataset.csv,
computes rule-based hepatic_vacuolation and kupffer_activation labels for
existing unlabeled sequences, and merges them into the training dataset.

Usage:
    python augment_hepatic_labels.py \
        --labeled data/processed/hepatic_endpoints_labeled.csv \
        --training data/processed/training_dataset.csv \
        --meta    data/processed/dataset_metadata.json \
        --out     data/processed/training_dataset_v2.csv
"""

import argparse
import re
import json
import pandas as pd
from pathlib import Path


# ── Rule-based labeling ──────────────────────────────────────────────────────
TOXIC_MOTIFS_VACUOLATION = ["TCC", "TGC"]   # Burdick 2014 (T1)
CpG_PATTERN = re.compile(r"CG", re.IGNORECASE)
LNP_CHEMISTRIES = {"LNP_ionizable", "LNP_cationic", "LNP_GalNAc_2OMe_PS"}
FIRST_GEN_CHEMISTRIES = {"PS_backbone_1st_gen"}


def rule_hepatic_vacuolation(row: pd.Series) -> int:
    """
    Returns 1 if rule-based evidence suggests hepatic vacuolation risk.

    Rules (additive, any one suffices):
      R1: LNA/cEt gapmer with TCC or TGC motif in gap sequence (Burdick 2014, T1)
      R2: Chemistry is LNP_ionizable at high dose context (lipid vacuolation)
      R3: Known hepatotoxic chemistry class (LNA/cEt) with PS backbone
    """
    seq = str(row.get("sequence", "")).upper()
    chem = str(row.get("chemistry", ""))
    mod  = str(row.get("modality", ""))

    # R1 — motif rule (LNA/cEt gapmers only, not universally applicable)
    is_high_affinity_gapmer = any(x in chem for x in ["LNA", "cEt"])
    motif_hit = any(m in seq for m in TOXIC_MOTIFS_VACUOLATION)
    if is_high_affinity_gapmer and motif_hit:
        return 1

    # R2 — LNP lipid vacuolation
    if chem in LNP_CHEMISTRIES or "LNP" in chem:
        return 1

    # R3 — chronic high-dose PS accumulation in liver
    ps_gapmer = "PS" in chem and "gapmer" in mod.lower() and len(seq) >= 18
    if ps_gapmer and any(x in chem for x in ["MOE", "LNA", "cEt"]):
        return 1

    return 0


def rule_kupffer_activation(row: pd.Series) -> int:
    """
    Returns 1 if rule-based evidence suggests Kupffer cell activation risk.

    Rules:
      R1: Unmethylated CpG dinucleotide present (TLR9/KC activation, sequence-dependent)
      R2: LNP carrier modality (phagocytosis-driven KC activation)
      R3: First-generation fully PS ASO (complement/polyanion pathway)
      R4: Long PS backbone >20mer with systemic route (class effect threshold)
    """
    seq  = str(row.get("sequence", "")).upper()
    chem = str(row.get("chemistry", ""))
    mod  = str(row.get("modality", ""))

    # R1 — CpG motif (unmethylated)
    if CpG_PATTERN.search(seq):
        return 1

    # R2 — LNP carrier
    if chem in LNP_CHEMISTRIES or "LNP" in chem:
        return 1

    # R3 — first-gen PS
    if chem in FIRST_GEN_CHEMISTRIES:
        return 1

    # R4 — long PS backbone systemic
    if "PS" in chem and len(seq) > 20:
        return 1

    return 0


def load_labeled(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["sequence"] = df["sequence"].str.upper().str.strip()
    return df


def merge_and_augment(labeled: pd.DataFrame, training: pd.DataFrame) -> pd.DataFrame:
    """
    Strategy:
      1. Sequences already in labeled CSV → use verified labels directly (gold standard).
      2. Sequences in training_dataset but not in labeled CSV → apply rule-based labels.
      3. Append labeled-only rows to training if sequence is novel.
    """
    labeled_seqs = set(labeled["sequence"].values)

    # -- Apply rule-based labels to training set rows not already gold-labeled --
    mask_unlabeled = ~training["sequence"].str.upper().str.strip().isin(labeled_seqs)
    training["sequence"] = training["sequence"].str.upper().str.strip()

    training.loc[mask_unlabeled, "label_hepatic_vacuolation"] =         training[mask_unlabeled].apply(rule_hepatic_vacuolation, axis=1)
    training.loc[mask_unlabeled, "label_kupffer_activation"] =         training[mask_unlabeled].apply(rule_kupffer_activation, axis=1)

    # -- Overwrite with gold labels where sequence matches --
    for _, row in labeled.iterrows():
        mask = training["sequence"] == row["sequence"]
        if mask.any():
            training.loc[mask, "label_hepatic_vacuolation"] = row["label_hepatic_vacuolation"]
            training.loc[mask, "label_kupffer_activation"]  = row["label_kupffer_activation"]

    # -- Append gold-labeled rows not in training --
    novel = labeled[~labeled["sequence"].isin(training["sequence"])].copy()
    if len(novel) > 0:
        training = pd.concat([training, novel], ignore_index=True)

    return training


def update_metadata(meta_path: Path, out_path: Path, n_total: int,
                    n_vacuolation: int, n_kupffer: int):
    with open(meta_path) as f:
        meta = json.load(f)
    meta["endpoints"] = meta.get("endpoints", [])
    for ep in ["hepatic_vacuolation", "kupffer_activation"]:
        if ep not in meta["endpoints"]:
            meta["endpoints"].append(ep)
    meta["training_dataset_v2"] = {
        "path": str(out_path),
        "n_sequences": n_total,
        "label_hepatic_vacuolation_positive": n_vacuolation,
        "label_kupffer_activation_positive": n_kupffer,
        "label_source": "gold_T1_T2_T3_plus_rule_based_augmentation",
        "augmentation_rules": {
            "hepatic_vacuolation": [
                "TCC/TGC motif in LNA/cEt gapmer (Burdick 2014 T1)",
                "LNP chemistry class",
                "Long PS backbone with high-affinity modification"
            ],
            "kupffer_activation": [
                "Unmethylated CpG motif (TLR9)",
                "LNP carrier modality",
                "First-gen PS class effect",
                "Long PS backbone >20mer"
            ]
        }
    }
    out_meta = meta_path.parent / "dataset_metadata_v2.json"
    with open(out_meta, "w") as f:
        json.dump(meta, f, indent=2)
    print(f"Updated metadata → {out_meta}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--labeled",  default="data/processed/hepatic_endpoints_labeled.csv")
    parser.add_argument("--training", default="data/processed/training_dataset.csv")
    parser.add_argument("--meta",     default="data/processed/dataset_metadata.json")
    parser.add_argument("--out",      default="data/processed/training_dataset_v2.csv")
    args = parser.parse_args()

    labeled_path  = Path(args.labeled)
    training_path = Path(args.training)
    meta_path     = Path(args.meta)
    out_path      = Path(args.out)

    print(f"Loading labeled examples from {labeled_path}")
    labeled = load_labeled(labeled_path)
    print(f"  {len(labeled)} gold-labeled sequences loaded")

    print(f"Loading training dataset from {training_path}")
    training = pd.read_csv(training_path)
    # Ensure required columns exist
    for col in ["label_hepatic_vacuolation", "label_kupffer_activation"]:
        if col not in training.columns:
            training[col] = 0
    print(f"  {len(training)} training sequences loaded")

    merged = merge_and_augment(labeled, training)

    vac_pos = int(merged["label_hepatic_vacuolation"].sum())
    kup_pos = int(merged["label_kupffer_activation"].sum())
    print(f"Merged dataset: {len(merged)} total sequences")
    print(f"  hepatic_vacuolation=1 : {vac_pos}")
    print(f"  kupffer_activation=1  : {kup_pos}")

    merged.to_csv(out_path, index=False)
    print(f"Saved → {out_path}")

    if meta_path.exists():
        update_metadata(meta_path, out_path, len(merged), vac_pos, kup_pos)
    else:
        print(f"WARN: metadata not found at {meta_path}, skipping metadata update")


if __name__ == "__main__":
    main()
